# Read me - Project 5 - Maze
## General Information
**Due date:** 4/25/24

**Class:** EECE2560 - Fundamentals of Algorithms

**Authors:** Group 1 - Daniel Costanzo and Rithvik Kaikaneni

**Note:** There are two main parts of this project present in this directory - part a (coskat-5a) and part b (coskat-5b).

## Scope of the project
n this project, you will develop algorithms that find paths through a maze.
The input is a text file containing a collection of mazes. Each maze begins with the number of rows
and columns in the maze and a character for every cell in the maze. A cell contains a space if the
solver is allowed to occupy the cell. A cell contains X if the solver is not allowed to occupy the cell.
The solver starts at cell (0,0) in the upper left, and the goal is to get to cell (rows-1, cols-1)
in the lower right. A legal move from a cell is to move left, right, up, or down to an immediately
adjacent cell that contains a space. Moving off any edge of the board is not allowed
## Requirements
***Part a requires the following:***

Functions to handle file I/O and a complete graph class, are included as part of the assign-
ment. In the printout of the graph, the current cell is represented by + and the goal cell is
represented by *. Add functions that:
1. Create a graph that represents the legal moves between cells. Each vertex should
   represent a cell, and each edge should represent a legal move between adjacent cells.


2. Write a recursive function findPathRecursive that looks for a path from the start cell
   to the goal cell. If a path from the start to the goal exists, your program should print a
   sequence of correct moves (Go left, go right, etc.). If no path from the start to the
   goal exists, the program should print, No path exists. Hint: consider recursive-DFS.


3. Write a function findPathNonRecursive that does the same thing as in 2, but without
   using recursion. Hint: consider either stack-based DFS or queue-based BFS.
   The code you submit should apply both findPath functions to each maze, one after the
   other. If a solution exists, the solver should simulate the solution to each maze by calling
   the maze::print() function after each move.
   Example of a maze input file:


   7

   10

   OXXXXXXXXX

   OOOOOOOOXX

   OXOXOXOXXX

   OXOXOXOOOO

   XXOXXXOXXX

   XOOOOOOOXX
   
   XXXXXXXOOOZ




***Part b requires the following:***

A shortest path in a maze is a path from the start to the goal with the smallest number of
steps. Write two functions findShortestPath1 and findShortestPath2 that each find a
shortest path in a maze if a path from the start to the goal exists.
The first algorithm should use a breadth-first search. The second algorithm should use
Dijkstra algorithm for shortest paths.
In each case, if a solution exists the solver should simulate the solution to each maze by
calling the maze::print() function after each move.
Each function should return true if any paths are found, and false otherwise.






## How to compile and run
***For part a:***

Open the `coskat5-a.cpp` file and run it through VSCode.

There is no input that the user must enter. The program will automatically solve the maze-1 given in the Canvas file. If 
you wish to change the file that is read, you must do this manually in the .cpp file mentioned above. The terminal will then
output the maze and if there's a path that can be found. It will also display the amount of steps neccessary to solve it for each method.

***For part b:***

Open the `coskat5-b.cpp` file and run it through VSCode.

There is no input that the user must enter. Similar to part a, the program will simply output the possible steps to the maze-solving path.
It will also display the amount of steps neccessary to solve it.
The algorithms are different, but they have the same intended functionality as before.
