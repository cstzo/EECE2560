#include <iostream>
#include <queue>
#include <list>
#include <fstream>
#include "d_except.h"
#include "d_matrix.h"
#include "graph.h"

using namespace std;

class maze
{
public:
    maze(ifstream &fin);
    void print(int,int,int,int);
    bool isLegal(int i, int j);

    void setMap(int i, int j, int n);
    int getMap(int i, int j) const;
    void mapMazeToGraph(graph &g);

    //Functions I added to achieve requested functionality of part a

     //This function finds the path recursively in a given maze
    bool findPathRecursive(graph& g, int start, int end, vector<int>& path);
    //This function finds the path using a non recursive method of a given maze
    bool findPathNonRecursive(graph& g, int start, int end, vector<int>& path);
    //This function outputs to the screen the maze's path
    void printPath(graph& g, vector<int> path, int target_i, int target_j);

    int rows; // number of rows in the maze
    int cols; // number of columns in the maze

private:
    matrix<bool> value;
    matrix<int> map;      // Mapping from maze (i,j) values to node index values
};

void maze::setMap(int i, int j, int n)
// Set mapping from maze cell (i,j) to graph node n.
{
    map[i][j] = n;
}

int maze::getMap(int i, int j) const
// Return mapping of maze cell (i,j) in the graph.
{
    return map[i][j];
}

maze::maze(ifstream &fin)
// Initializes a maze by reading values from fin.  Assumes that the
// number of rows and columns indicated in the file are correct.
{
    fin >> rows;
    fin >> cols;

    char x;

    value.resize(rows,cols);
    for (int i = 0; i <= rows-1; i++)
        for (int j = 0; j <= cols-1; j++)
        {
            fin >> x;
            if (x == 'O')
                value[i][j] = true;
            else
                value[i][j] = false;
        }

    map.resize(rows,cols);
}

void maze::print(int goalI, int goalJ, int currI, int currJ)
// Print out a maze, with the goal and current cells marked on the
// board.
{
    cout << endl;

    if (goalI < 0 || goalI > rows-1 || goalJ < 0 || goalJ > cols-1)
        throw rangeError("Bad value in maze::print");

    if (currI < 0 || currI > rows-1 || currJ < 0 || currJ > cols-1)
        throw rangeError("Bad value in maze::print");

    for (int i = 0; i <= rows-1; i++)
    {
        for (int j = 0; j <= cols-1; j++) {
            if (i == goalI && j == goalJ)
                cout << "*";
            else
            if (i == currI && j == currJ)
                cout << "+";
            else
            if (value[i][j])
                cout << " ";
            else
                cout << "X";
        }
        cout << endl;
    }
    cout << endl;
}

//This function was given in the basecode template and creates a graph that stores and represents the legal moves
void maze::mapMazeToGraph(graph &g)
// Create a graph g that represents the legal moves in the maze m.
{

    //initial for loop that iterates through the maze rows and columns, adding nodes where appropriate
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            g.addNode(1); //using functions from the graph header
            setMap(i, j, g.numNodes() - 1); //called from the graph header
        }
    }

    //this for loop will run until all the values are checked for validity in the given maze
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            //if statement that checks if the current cell is legal using member function
            if(isLegal(i, j))
            {
                //if statement to check the validity of the move above
                if (j - 1 > 0) {
                    if (isLegal(i, j - 1)) {
                        g.addEdge(getMap(i, j), getMap(i, j - 1)); //adds an edge using the edge class member function
                    }
                }

                //if statement to check the validity of the move below
                if (j + 1 < cols) {
                    if (isLegal(i, j + 1)) {
                        g.addEdge(getMap(i, j), getMap(i, j + 1)); //adds an edge using the edge class member function
                    }
                }

                //if statement to check the validity of the move right
                if(i + 1 < rows) {
                    if (isLegal(i + 1, j)) {
                        g.addEdge(getMap(i, j), getMap(i + 1, j)); //adds an edge using the edge class member function
                    }

                //if statement to check the validity of the move left
                if(i - 1 > 0) {
                    if (isLegal(i - 1, j)) {
                        g.addEdge(getMap(i, j), getMap(i - 1, j)); //adds an edge using the edge class member function
                    }
                }

                }
            }
        }
    }
}


//This function uses DFS recursion to find a path within the given maze
bool maze::findPathRecursive(graph& g, int start, int end, vector<int> &mazePath) {

    g.visit(start); //the initial node is marked as visited
    
    if (start == end) {return true;} //if statement to check the default case where there is only one value in the path

    // for loop that traverses the nodes in graph to check if they're already visited or marked
    for (int i = 0; i < g.numNodes(); i++) {
        if (i != start){
            if (g.isEdge(start, i) && !g.isVisited(i) && !g.isMarked(i)){
                g.mark(i); //if condition is met this is marked as marked so that it is not read again in recursion

                //This if statement uses recursion (as a boolean if statement) to continue solving the path
                if (findPathRecursive(g, i, end, mazePath)) {
                    mazePath.push_back(i);
                    return true;
                }
                g.unMark(i); //unmarks the value
            }
        }
    }
    return false; //will otherwise return false
}

// This function checks if a cell value at index (i,j) in the maze is valid or not
bool maze::isLegal(int i, int j){

    //if statement to check if in range
    if (i < 0 || i > rows-1 || j < 0 || j > cols-1)
        throw rangeError("Bad value in maze::isLegal"); //calls error from given exception header file

    return value[i][j]; //returns value otherwise
}

//This function finds a path within a given maze iteratively
bool maze::findPathNonRecursive(graph& g, int start, int end, vector<int>& mazePath) {

    queue<int> neighborQueue; //establishing a new queue of integers

    //clear any markings or visiting flags that may be already in the new queue
    g.clearMark();
    g.clearVisit();

    neighborQueue.push(start); //pushing the starting node into the new queue
    g.visit(start); //the initial starting node is marked as being visited

    int previousNode;//declares integer variable to keep track of node indices

    vector<int> pathMoves; //a vector is initialized to keep track of the nodes already validated for the path
    pathMoves.resize(g.numNodes()); //resizes appropriately with the size of nodes from the maze


    //while loop that will terminate when the queue of neighboring nodes is empty
    while(!neighborQueue.empty()) {

        //if statement for case when there is only one element left in the queue
        if (neighborQueue.front() == end) {
            int temp = end; //sets the end to be a temporary value
            mazePath.push_back(end); //pushes it to the path

            //while loop that runs until the temp value(end) is equal to that of start, pushing back the moves to the vector of moves
            while (temp != start) {
                mazePath.push_back(pathMoves[temp]);
                temp = pathMoves[temp]; //resets temp
            }
            mazePath.pop_back(); //removes value from mazePath data container
            return true;
        }
        previousNode = neighborQueue.front();

        //for loop iterates through every node, adding the values to the queue of neighbor nodes
        //this is done by validating that en edge exists between each node pair
        for (int i = 0; i < g.numNodes(); i++) {

            //if statement to check if a node is found, adding it approproately to the queue of neighbors initiated earlier
            if(g.isEdge(previousNode, i) && !g.isVisited(i) && !g.isMarked(i)) {
                g.mark(i); //marks value
                neighborQueue.push(i); //pushes to queue
                pathMoves[i] = previousNode; //changes index to previousNode
            }
        }
        g.visit(previousNode); //call to visit the previous node
        neighborQueue.pop(); //makes the front of the queue become the next predecessor node
    }
    return false;

}

// This function prints a path (if found) using breadth first search or depth first search
void maze::printPath(graph& g, vector<int> path, int target_i, int target_j) {

    //first checks if a possible path even exists 
    if (path.empty()) {
        //output to screen
        cout << "No path could be found for your maze";
        return; // ends statement if true
    }

    cout << "A solution to the maze was found in " << path.size() << " moves: " << endl;

    //instantiate counter variables for the loop below 
    int curr_i, curr_j;
    curr_i = 0;
    curr_j = 0;

    //for loop that iterates through the entire path
    for (int n = 0; n < path.size(); n++) {
        int next_i, next_j;

        //sets the index to the path at a specific index
        int nodeIndex = path[path.size() - 1 - n];

        //nested for loop to iterate through each node in the maze and find their coordinates
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                //checks if the index matches the target
                if (nodeIndex == getMap(i, j)) {
                    next_i = i;
                    next_j = j;
                    break; //ends loop once this statement is executed 
                }
            }
        }

        //string variable declared to store the direction
        string dir;

        //if statements to determine move direction
        if (next_i < curr_i) {
            dir = "Upwards";
        }
        else if (next_i > curr_i) {
            dir = "Downwards";
        }
        else if (next_j > curr_j) {
            dir = "To the right";
        }
        else if (next_j < curr_j) {
            dir = "To the left";
        }

        cout << "Move #" << n + 1 << ": " << dir << endl;
        
        curr_i = next_i; //i position gets updated 
        curr_j = next_j; //j position gets updated
        
        //outputs the new move on the maze to the screen 
        this->print(target_i, target_j, curr_i, curr_j);
    }
}



int main()
{
    char x;
    ifstream fin;

    //reads the maze from the file.
    string fileName = "maze1.txt";

    fin.open(fileName.c_str());
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        exit(1);
    }

    try
    {

        graph g;
        while (fin && fin.peek() != 'Z')
        {
            maze m(fin);

            m.mapMazeToGraph(g); //creates a graph from the given maze

            g.clearMark();
            g.clearVisit();

            cout << "Finding a path to the given maze.." << endl;

            vector<int> dfsPath; //declares vector to store the steps of the recursive path solution
            if (m.findPathRecursive(g, m.getMap(0, 0), m.getMap(m.rows-1, m.cols-1), dfsPath)) {
                cout << "A path was found recursively. See below:" << endl;

                //prints the recursive path
                m.printPath(g, dfsPath, m.rows-1, m.cols-1);
            }
            else {cout << "No path could be found recursively";}
            
            vector<int> iterativePath; //declares vector to store the steps of the iterative path solution
            if (m.findPathNonRecursive(g, m.getMap(0, 0), m.getMap(m.rows-1, m.cols-1), iterativePath)) {
                cout << "An iterative path was found. See below:" << endl;

                //prints the iterative path
                m.printPath(g, iterativePath, m.rows-1, m.cols-1);
            }
            else {cout << "No path could be found iteratively";}

        }

        //will output if the maze has been solved
        if (fin.peek() == 'Z'){
            cout << "SOLVED" << endl;
        }

    }
    catch (indexRangeError &ex)
    {
        cout << ex.what() << endl; exit(1);
    }
    catch (rangeError &ex)
    {
        cout << ex.what() << endl; exit(1);
    }
}
