#include <iostream>
#include <queue>
#include <list>
#include <fstream>
#include "d_except.h"
#include "d_matrix.h"
#include "graph.h"

using namespace std;

class maze
{
public:
    maze(ifstream &fin);
    void print(int,int,int,int);
    bool isLegal(int i, int j);

    void setMap(int i, int j, int n);
    int getMap(int i, int j) const;
    void mapMazeToGraph(graph &g);

    //Functions I added to achieve requested functionality of part a

    //This function finds the path recursively in a given maze
    bool findPathRecursive(graph& g, int start, int end, vector<int>& path);
    //This function finds the path using a non recursive method of a given maze
    bool findPathNonRecursive(graph& g, int start, int end, vector<int>& path);
    //This function outputs to the screen the maze's path
    void printPath(graph& g, vector<int> path, int target_i, int target_j);


    //Functions I added to achieve requested functionality of part b

    //This function finds the shortest path through the maze using BFS node traversal
    bool findShortestPath1(graph& g, int start, int end, vector<int>& path);

    //This function finds the shortest path through the maze using Dijkstra's algorithm
    bool findShortestPath2(graph& g, int start, int end, vector<int> &mazePath);


    int rows; // number of rows in the maze
    int cols; // number of columns in the maze

private:
    matrix<bool> value;
    matrix<int> map;      // Mapping from maze (i,j) values to node index values
};

void maze::setMap(int i, int j, int n)
// Set mapping from maze cell (i,j) to graph node n.
{
    map[i][j] = n;
}

int maze::getMap(int i, int j) const
// Return mapping of maze cell (i,j) in the graph.
{
    return map[i][j];
}

maze::maze(ifstream &fin)
// Initializes a maze by reading values from fin.  Assumes that the
// number of rows and columns indicated in the file are correct.
{
    fin >> rows;
    fin >> cols;

    char x;

    value.resize(rows,cols);
    for (int i = 0; i <= rows-1; i++)
        for (int j = 0; j <= cols-1; j++)
        {
            fin >> x;
            if (x == 'O')
                value[i][j] = true;
            else
                value[i][j] = false;
        }

    map.resize(rows,cols);
}

void maze::print(int goalI, int goalJ, int currI, int currJ)
// Print out a maze, with the goal and current cells marked on the
// board.
{
    cout << endl;

    if (goalI < 0 || goalI > rows-1 || goalJ < 0 || goalJ > cols-1)
        throw rangeError("Bad value in maze::print");

    if (currI < 0 || currI > rows-1 || currJ < 0 || currJ > cols-1)
        throw rangeError("Bad value in maze::print");

    for (int i = 0; i <= rows-1; i++)
    {
        for (int j = 0; j <= cols-1; j++) {
            if (i == goalI && j == goalJ)
                cout << "*";
            else
            if (i == currI && j == currJ)
                cout << "+";
            else
            if (value[i][j])
                cout << " ";
            else
                cout << "X";
        }
        cout << endl;
    }
    cout << endl;
}

//This function was given in the basecode template and creates a graph that stores and represents the legal moves
void maze::mapMazeToGraph(graph &g)
// Create a graph g that represents the legal moves in the maze m.
{

    //initial for loop that iterates through the maze rows and columns, adding nodes where appropriate
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            g.addNode(1); //using functions from the graph header
            setMap(i, j, g.numNodes() - 1); //called from the graph header
        }
    }

    //this for loop will run until all the values are checked for validity in the given maze
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            //if statement that checks if the current cell is legal using member function
            if(isLegal(i, j))
            {
                //if statement to check the validity of the move above
                if (j - 1 > 0) {
                    if (isLegal(i, j - 1)) {
                        g.addEdge(getMap(i, j), getMap(i, j - 1)); //adds an edge using the edge class member function
                    }
                }

                //if statement to check the validity of the move below
                if (j + 1 < cols) {
                    if (isLegal(i, j + 1)) {
                        g.addEdge(getMap(i, j), getMap(i, j + 1)); //adds an edge using the edge class member function
                    }
                }

                //if statement to check the validity of the move right
                if(i + 1 < rows) {
                    if (isLegal(i + 1, j)) {
                        g.addEdge(getMap(i, j), getMap(i + 1, j)); //adds an edge using the edge class member function
                    }

                    //if statement to check the validity of the move left
                    if(i - 1 > 0) {
                        if (isLegal(i - 1, j)) {
                            g.addEdge(getMap(i, j), getMap(i - 1, j)); //adds an edge using the edge class member function
                        }
                    }

                }
            }
        }
    }
}


//This function uses DFS recursion to find a path within the given maze
bool maze::findPathRecursive(graph& g, int start, int end, vector<int> &mazePath) {

    g.visit(start); //the initial node is marked as visited

    if (start == end) {return true;} //if statement to check the default case where there is only one value in the path

    // for loop that traverses the nodes in graph to check if they're already visited or marked
    for (int i = 0; i < g.numNodes(); i++) {
        if (i != start){
            if (g.isEdge(start, i) && !g.isVisited(i) && !g.isMarked(i)){
                g.mark(i); //if condition is met this is marked as marked so that it is not read again in recursion

                //This if statement uses recursion (as a boolean if statement) to continue solving the path
                if (findPathRecursive(g, i, end, mazePath)) {
                    mazePath.push_back(i);
                    return true;
                }
                g.unMark(i); //unmarks the value
            }
        }
    }
    return false; //will otherwise return false
}

// This function checks if a cell value at index (i,j) in the maze is valid or not
bool maze::isLegal(int i, int j){

    //if statement to check if in range
    if (i < 0 || i > rows-1 || j < 0 || j > cols-1)
        throw rangeError("Bad value in maze::isLegal"); //calls error from given exception header file

    return value[i][j]; //returns value otherwise
}

//This function finds a path within a given maze iteratively
bool maze::findPathNonRecursive(graph& g, int start, int end, vector<int>& mazePath) {

    queue<int> neighborQueue; //establishing a new queue of integers

    //clear any markings or visiting flags that may be already in the new queue
    g.clearMark();
    g.clearVisit();

    neighborQueue.push(start); //pushing the starting node into the new queue
    g.visit(start); //the initial starting node is marked as being visited

    int previousNode;//declares integer variable to keep track of node indices

    vector<int> pathMoves; //a vector is initialized to keep track of the nodes already validated for the path
    pathMoves.resize(g.numNodes()); //resizes appropriately with the size of nodes from the maze


    //while loop that will terminate when the queue of neighboring nodes is empty
    while(!neighborQueue.empty()) {

        //if statement for case when there is only one element left in the queue
        if (neighborQueue.front() == end) {
            int temp = end; //sets the end to be a temporary value
            mazePath.push_back(end); //pushes it to the path

            //while loop that runs until the temp value(end) is equal to that of start, pushing back the moves to the vector of moves
            while (temp != start) {
                mazePath.push_back(pathMoves[temp]);
                temp = pathMoves[temp]; //resets temp
            }
            mazePath.pop_back(); //removes value from mazePath data container
            return true;
        }
        previousNode = neighborQueue.front();

        //for loop iterates through every node, adding the values to the queue of neighbor nodes
        //this is done by validating that en edge exists between each node pair
        for (int i = 0; i < g.numNodes(); i++) {

            //if statement to check if a node is found, adding it approproately to the queue of neighbors initiated earlier
            if(g.isEdge(previousNode, i) && !g.isVisited(i) && !g.isMarked(i)) {
                g.mark(i); //marks value
                neighborQueue.push(i); //pushes to queue
                pathMoves[i] = previousNode; //changes index to previousNode
            }
        }
        g.visit(previousNode); //call to visit the previous node
        neighborQueue.pop(); //makes the front of the queue become the next predecessor node
    }
    return false;

}

//This function was added to satisfy the requirements of part b of this project
//It is able to solve the maze by traversing through the nodes using a BFS technique learned in class
bool maze::findShortestPath1(graph& g, int start, int end, vector<int> &mazePath) {
    queue<int> temp_queue;
    //vectors to track visited and parent nodes
    vector<bool> visitedNode(g.numNodes(), false);
    vector<int> parentNode(g.numNodes(), -1);

    //pushes starting node onto the temp queue
    temp_queue.push(start);
    //sets visited flag to be true as default
    visitedNode[start] = true;

    int current, neighbor; //variable declarations to store current ad neighbor nodes
    
    //while loop that will run until the newly established queue is empty
    while (!temp_queue.empty()){
        
        current = temp_queue.front();
        temp_queue.pop(); //pops value from queue

        //adds values to vector storing the steps in the path
        if (current == end) {
            while (current != -1) { //stopping condition
                mazePath.push_back(current);
                current = parentNode[current]; //updates current node to be parent node
            }
            return true;
        }
        
        //for loop to explore any neighbors of the current node 
        for (int i = 0; i < g.numNodes(); i++) {
            if (g.isEdge(current, i) && !visitedNode[i]) {

                //if visited the node, marks as true
                visitedNode[i] = true;
                
                //pushes the node onto the queue
                temp_queue.push(i);
                
                //current node set to be the neighbor's parent node
                parentNode[i] = current;
            }
        }
    }
    
    return false;
}


//This function was added to satisfy the requirements of part b of this project
//It finds the shortest path in a maze using the Dijkstra's algorithm that takes into account edge weights

bool maze::findShortestPath2(graph& g, int start, int end, vector<int> &mazePath) {

    //vectors to track visited and parent nodes
    vector<bool> visitedNode(g.numNodes(), false);
    vector<int> parentNode(g.numNodes(), -1);
    //vector to track weigted distanced between nodes
    vector<int> dist(g.numNodes(), 1e9);

    dist[start] = 0; //the starting node is initialized to have a distance of 0 units

    //for loop that calculated Dijkstra's algorithm using the weights in the maze
    //it keeps track of the distance between nodes to decide what the next best move is
    for (int n = 0; n < g.numNodes() - 1; n++) {

        //variable declared for absolute comparisons made
        int minPossible = 1e9;
        int u = -1;

        //for loop that will iterate through all nodes
        for (int i = 0; i < g.numNodes(); i++){
            //if statement to check node with smallest distance from the unvisited ones
            if (!visitedNode[i] && dist[i] < minPossible) {
                minPossible = dist[i];
                u = i;
            }
        }
        //stops the algorithm if the condition above isn't met
        if (u == -1) {break;}
        visitedNode[u] = true; //the current node is marked as already visited for later

        //the neighboring nodes are explored to see which is the closest one
        for (int v = 0; v < g.numNodes(); v++) {
            if (g.isEdge(u, v) && !visitedNode[v]) {
                int weight = g.getEdgeWeight(u, v); //grabs edge weight using functions in the graph header file

                //compares distances to each other
                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parentNode[v] = u; //changes parent is statement is met
                }
            }
        }
    }

    //if statement to reconstruct the solved path
    if (visitedNode[end]) {
        int val = end;
        //continues to push values into the path vector until empty
        while (val != false) {
            mazePath.push_back(val);
            val = parentNode[val]; //updates value to push
        }
        return true;
    }

    return false;
}



//this function prints a path (if found) using breadth first search or depth first search
void maze::printPath(graph& g, vector<int> path, int target_i, int target_j) {

    //first checks if a possible path even exists 
    if (path.empty()) {
        //output to screen
        cout << "No path could be found for your maze";
        return; // ends statement if true
    }

    cout << "A solution to the maze was found in " << path.size() << " moves: \n" << endl;

    //instantiate counter variables for the loop below
    int curr_i, curr_j;
    curr_i = 0;
    curr_j = 0;

    for (int n = 0; n < path.size(); n++) {
        int next_i, next_j;

        //sets the index to the path at a specific index
        int nodeIndex = path[path.size() - 1 - n];

        //nested for loop to iterate through each node in the maze and find their coordinates
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {

                //checks if the index matches the target
                if (nodeIndex == getMap(i, j)) {
                    next_i = i;
                    next_j = j;
                    break; //ends loop once this statement is executed
                }
            }
        }

        //string variable declared to store the direction
        string dir;

        //if statements to determine move direction
        if (next_i < curr_i) {
            dir = "Upwards";
        }
        else if (next_i > curr_i) {
            dir = "Downwards";
        }
        else if (next_j > curr_j) {
            dir = "To the right";
        }
        else if (next_j < curr_j) {
            dir = "To the left";
        }
        cout << "Move #" << n + 1 << ": " << dir << endl;

        curr_i = next_i; //i position gets updated
        curr_j = next_j; //j position gets updated

        //outputs the new move on the maze to the screen
        this->print(target_i, target_j, curr_i, curr_j);
    }
}



int main()
{
    char x;
    ifstream fin;

    //reads the maze from the file.
    string fileName = "maze1.txt";

    fin.open(fileName.c_str());
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        exit(1);
    }

    try
    {

        graph g;
        while (fin && fin.peek() != 'Z') {
            maze m(fin);

            m.mapMazeToGraph(g); //creates a graph from the given maze

            //clears any nodes that have been marked or visited already
            g.clearMark();
            g.clearVisit();

            cout << "Finding a path to the given maze.." << endl;

            //The function calls below have been commented out since they're from part a

//            vector<int> dfsPath; //declares vector to store the steps of the recursive path solution
//            if (m.findPathRecursive(g, m.getMap(0, 0), m.getMap(m.rows - 1, m.cols - 1), dfsPath)) {
//                cout << "A path was found recursively. See below:" << endl;
//
//                //prints the path
//                m.printPath(g, dfsPath, m.rows - 1, m.cols - 1);
//
//            } else { cout << "No path could be found recursively" << endl; }
//
//            vector<int> iterativePath; //declares vector to store the steps of the iterative path solution
//            if (m.findPathNonRecursive(g, m.getMap(0, 0), m.getMap(m.rows - 1, m.cols - 1), iterativePath)) {
//                cout << "An iterative path was found. See below:" << endl;
//
//                //prints the path
//                m.printPath(g, iterativePath, m.rows - 1, m.cols - 1);
//
//            } else { cout << "No path could be found iteratively" << endl; }


            // The following two if-else statements are from part b

            vector<int> shortestPathBFS; //declares vector to store the steps of the iterative path solution
            if (m.findShortestPath1(g, m.getMap(0, 0), m.getMap(m.rows - 1, m.cols - 1), shortestPathBFS)) {
                cout << "The shortest path was found using BFS" << endl;

                //prints the path
                m.printPath(g, shortestPathBFS, m.rows - 1, m.cols - 1);

            } else {cout << "No shortest path could be found using BFS" << endl;}


            vector<int> shortestPathDijkstra; //declares vector to store the steps of the iterative path solution
            if (m.findShortestPath2(g, m.getMap(0, 0), m.getMap(m.rows - 1, m.cols - 1), shortestPathDijkstra)) {
                cout << "The shortest path was found using Dijkstra's algorithm" << endl;

                //prints the path
                m.printPath(g, shortestPathDijkstra, m.rows - 1, m.cols - 1);

            } else {cout << "No shortest path could be found using Dijkstra's algorithm" << endl; }


        }

        //will output if the maze has been solved
        if (fin.peek() == 'Z'){
            cout << "SOLVED" << endl;
        }
    }

    catch (indexRangeError &ex)
    {
        cout << ex.what() << endl; exit(1);
    }
    catch (rangeError &ex)
    {
        cout << ex.what() << endl; exit(1);
    }


}
