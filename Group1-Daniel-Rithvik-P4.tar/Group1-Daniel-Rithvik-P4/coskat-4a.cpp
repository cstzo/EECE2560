#include <iostream>
#include <limits.h>
#include "d_matrix.h"
#include "d_except.h"
#include <list>
#include <fstream>
#include <vector>

using namespace std;

typedef int ValueType; // The type of the value in a cell
const int Blank = -1;  // Indicates that a cell is blank

const int SquareSize = 3;  //  The number of cells in a small square
//  (usually 3).  The board has
//  SquareSize^2 rows and SquareSize^2
//  columns.

const int BoardSize = SquareSize * SquareSize;

const int MinValue = 1;
const int MaxValue = 9;

int numSolutions = 0;

class board
// Stores the entire Sudoku board
{
public:

    //Functionality given by the basic code pfg
    board(int);
    void clear();
    void initialize(ifstream &fin);
    void print();
    bool isBlank(int, int);
    ValueType getCell(int, int);

    //Functionality I added to fulfill project requirements
    void setCell(int i, int j, int given); //sets the value of a cell
    void printConflicts(); //outputs any conflicts in the given board
    bool isSolved(); //checks to see if a puzzle is solved successfully
    void clearCell(int i, int j, int given); //clears value in a cell when called

private:

    // The following matrices go from 1 to BoardSize in each
    // dimension, i.e., they are each (BoardSize+1) * (BoardSize+1)
    matrix<ValueType> value;

    // 2d arrays of booleans containing whether each row, column, or square conflicts with a given digit.
    bool rowConflicts[BoardSize][BoardSize], colConflicts[BoardSize][BoardSize], squareConflicts[BoardSize][BoardSize];
};

board::board(int sqSize)
        : value(BoardSize+1,BoardSize+1)
// Board constructor
{
    clear();
}

void board::clear()
// Mark all possible values as legal for each board entry
{
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            value[i][j] = Blank;
        }
}

void board::initialize(ifstream &fin)
// Read a Sudoku board from the input file.
{
    char ch;

    clear();

    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            fin >> ch;

            // If the read char is not Blank
            if (ch != '.')
                setCell(i,j,ch-'0');   // Convert char to int
        }
}

int squareNumber(int i, int j)
// Return the square number of cell i,j (counting from left to right,
// top to bottom.  Note that i and j each go from 1 to BoardSize
{
    // Note that (int) i/SquareSize and (int) j/SquareSize are the x-y
    // coordinates of the square that i,j is in.

    return SquareSize * ((i-1)/SquareSize) + (j-1)/SquareSize + 1;
}

ostream &operator<<(ostream &ostr, vector<int> &v)
// Overloaded output operator for vector class.
{
    for (int i = 0; i < v.size(); i++)
        ostr << v[i] << " ";
    cout << endl;
    return ostr;
}

ValueType board::getCell(int i, int j)
// Returns the value stored in a cell.  Throws an exception
// if bad values are passed.
{
    if (i >= 1 && i <= BoardSize && j >= 1 && j <= BoardSize)
        return value[i][j];
    else
        throw rangeError("bad value in getCell");
}

// Set the value in the cell at (i, j) to the given value
// and update conflicts

bool board::isBlank(int i, int j){
// Returns true if cell i,j is blank, and false otherwise

    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad value in setCell");

    return (getCell(i,j) == Blank);
}

void board::print()
// Prints the current board.
{
    for (int i = 1; i <= BoardSize; i++)
    {
        if ((i-1) % SquareSize == 0)
        {
            cout << " -";
            for (int j = 1; j <= BoardSize; j++)
                cout << "---";
            cout << "-";
            cout << endl;
        }
        for (int j = 1; j <= BoardSize; j++)
        {
            if ((j-1) % SquareSize == 0)
                cout << "|";
            if (!isBlank(i,j))
                cout << " " << getCell(i,j) << " ";
            else
                cout << "   ";
        }
        cout << "|";
        cout << endl;
    }

    cout << " -";
    for (int j = 1; j <= BoardSize; j++)
        cout << "---";
    cout << "-";
    cout << endl;
}

//this function will set the value of each cell, updating each conflict vector
void board::setCell(int i, int j, int given){
    //set specific sell values
    value[i][j] = given;

    //update conflict vectors
    rowConflicts[i - 1][given - 1] = true; //for the rows
    colConflicts[j - 1][given - 1] = true; //for the columns
    squareConflicts[squareNumber(i, j) - 1][given - 1] = true; //for the squares
}



//This void type function prints all the conflicts that are found when iterating through the board
void board::printConflicts() {

    //for loop that iterates through each row
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for row #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":";//outputs index

            if (rowConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }

    //column conflicts are determined and printed to the screen
    cout << endl;
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for column #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":"; //outputs index
            if (colConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }

    //conflicts for each sudoku square are output
    cout << endl;
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for square #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":"; //outputs index
            if (squareConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }
}

//This function checks to see if the given board has been solved or not
bool board::isSolved()
{
    //for loop that iterates through all the rows and columns of the board, checking for blank squares
    for(int i = 1; i <= BoardSize; i++){
        for(int j = 1; j <= BoardSize; j++){
            if (isBlank(i,j)){
                return false; //returns false if a cell is empty
            }
        }
    }
    return true; //returns through if there are no blank cells
}

//void type function to clear a cell; takes indices for cell and a value
void board::clearCell(int i, int j, int given) {

    value[i][j] = Blank; //set initial value of a cell if empty

    //update conflicts
    rowConflicts[i - 1][given - 1] = false;
    colConflicts[j - 1][given - 1] = false;
    squareConflicts[squareNumber(i, j) - 1][given - 1] = false;
}

int main()
{
    ifstream fin;

    // Read the sample grid from the file.
    string fileName = "sudoku2.txt";


    cout << "Attempting to open file: " << fileName << endl;
    fin.open(fileName.c_str());
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        exit(1);
    }

    try
    {
        board b1(SquareSize);

        while (fin && fin.peek() != 'Z')
        {
            b1.initialize(fin); //initializes board
            cout << "\n"; //new line
            b1.print(); //prints the sudoku puzzle
            cout << "\n"; //new line
            b1.printConflicts(); //outputs conflicts to the terminal
            cout << '\n'; //new line
            cout << (b1.isSolved() ? "Board is solved!" : "Board is not solved."); //turnery to display appropriate output
        }
    }
    catch  (indexRangeError &ex)
    {
        cout << ex.what() << endl;
        exit(1);
    }
}
