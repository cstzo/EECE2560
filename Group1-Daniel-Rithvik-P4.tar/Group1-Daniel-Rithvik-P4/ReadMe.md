# Read me - Project 4 - Sudoku Puzzle
## General Information
**Due date:** 4/5/24

**Class:** EECE2560 - Fundamentals of Algorithms

**Authors:** Group 1 - Daniel Costanzo and Rithvik Kaikaneni

**Note:** There are two main parts of this project present in this directory - part a (coskat-4a) and part b (coskat-4b).

## Scope of the project
Write a program that solves Sudoku puzzles. The input to Sudoku is a 9x9 board that is subdivided
into 3x3 squares. Each cell is either blank or contains an integer from 1 to 9.
A solution to a puzzle is the same board with every blank cell filled in with a digit from 1 to 9 such
that every digit appears exactly once in every row, column, and square.
The input to the program is a text file containing a collection of Sudoku boards, with one board
per line. For example:

.....2.......7...17..3...9.8..7......2.89.6...13..6....9..5.824.....891..........
3...8.......7....51..............36...2..4....7...........6.13..452...........8..Z

For each board that is read, the output is a printout of the board correctly filled in.

## Requirements
***Part a requires the following:***

Some of the declarations and definitions for the board class are given to you. Add functions
to the class that:
1. initialize the board, and update conflicts vectors,
2. print the board and the conflicts vectors to the screen,
3. add a value to a cell, and update conflicts vectors,
4. clear a cell, and update conflicts vectors, and
5. check to see if the board has been solved (return true or false, and print the result to
   the screen)


   The code you submit should read each Sudoku board from the file one-by-one, print the
   board and conflicts vectors to the screen, and check to see if the board has been solved (all
   boards will not be solved at this point).



***Part b requires the following:***

Complete your program that solves Sudoku puzzles. Your algorithm should be based on
recursion.
Your algorithm should read each board from the text file, solve it, print the solution, and
print the number of recursive iterations needed to solve that board. After all boards have
been solved, print the average number of recursive calls needed to solve all the boards.
Print the total number of your recursive calls.





## How to compile and run
***For part a:***

Open the `coskat4-a.cpp` file and run it through VSCode.

There is no input that the user must enter. The script will read from the given sudoku board and output the grid as-is.
The conflicts for each row, column, and square within the board will be displayed using boolean
values "True" or "False". 

***For part b:***

Open the `coskat4-b.cpp` file and run it through VSCode.

There is no input that the user must enter. The script will read from the given sudoku board and output the grids as-is.
The program will then solve the sudoku board and output it when done. It will then display the amount of recursions calls needed as well as the average
calls for all the boards.
