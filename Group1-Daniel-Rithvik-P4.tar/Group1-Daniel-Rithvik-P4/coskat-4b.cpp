#include <iostream>
#include <limits.h>
#include "d_matrix.h"
#include "d_except.h"
#include <list>
#include <fstream>
#include <vector>

using namespace std;

typedef int ValueType; // The type of the value in a cell
const int Blank = -1;  // Indicates that a cell is blank

const int SquareSize = 3;  //  The number of cells in a small square
//  (usually 3).  The board has
//  SquareSize^2 rows and SquareSize^2
//  columns.

const int BoardSize = SquareSize * SquareSize;

const int MinValue = 1;
const int MaxValue = 9;

int numSolutions = 0;

struct cell {
    int i = Blank;
    int j = Blank;
    vector<int> values;
};

class board
// Stores the entire Sudoku board
{
public:

    //Functionality given by the basic code pfg
    board(int);
    void clear();
    void initialize(ifstream &fin);
    void print();
    bool isBlank(int, int);
    ValueType getCell(int, int);

    //Functionality I added to fulfill project requirements (part a)
    void setCell(int i, int j, int given); //sets the value of a cell
    void printConflicts(); //outputs any conflicts in the given board
    bool isSolved(); //checks to see if a puzzle is solved successfully
    void clearCell(int i, int j, int given); //clears value in a cell when called

    //Added for part b
    bool solveBoard(); //function that solves the sudoku puzzle with backtracking
    cell findConstrainCell(); //function to find a target cell with the most rule constraints

private:

    // The following matrices go from 1 to BoardSize in each
    // dimension, i.e., they are each (BoardSize+1) * (BoardSize+1)
    matrix<ValueType> value;

    // 2d arrays of booleans containing whether each row, column, or square conflicts with a given digit.
    bool rowConflicts[BoardSize][BoardSize], colConflicts[BoardSize][BoardSize], squareConflicts[BoardSize][BoardSize];
};

board::board(int sqSize)
        : value(BoardSize+1,BoardSize+1)
// Board constructor
{
    clear();
}

void board::clear()
// Mark all possible values as legal for each board entry
{
    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            value[i][j] = Blank;
        }

    //nested for loop to check the possible conflicts within the rows, columns, and squares
    for (int i = 0; i < BoardSize; i++) {
        for (int j = 0; j < BoardSize; j++) {
            rowConflicts[i][j] = colConflicts[i][j] = squareConflicts[i][j] = false;
        }
    }
}

void board::initialize(ifstream &fin)
// Read a Sudoku board from the input file.
{
    char ch;

    clear();

    for (int i = 1; i <= BoardSize; i++)
        for (int j = 1; j <= BoardSize; j++)
        {
            fin >> ch;

            // If the read char is not Blank
            if (ch != '.')
                setCell(i,j,ch-'0');   // Convert char to int
        }
}

int squareNumber(int i, int j)
// Return the square number of cell i,j (counting from left to right,
// top to bottom.  Note that i and j each go from 1 to BoardSize
{
    // Note that (int) i/SquareSize and (int) j/SquareSize are the x-y
    // coordinates of the square that i,j is in.

    return SquareSize * ((i-1)/SquareSize) + (j-1)/SquareSize + 1;
}

ostream &operator<<(ostream &ostr, vector<int> &v)
// Overloaded output operator for vector class.
{
    for (int i = 0; i < v.size(); i++)
        ostr << v[i] << " ";
    cout << endl;
    return ostr;
}

ValueType board::getCell(int i, int j)
// Returns the value stored in a cell.  Throws an exception
// if bad values are passed.
{
    if (i >= 1 && i <= BoardSize && j >= 1 && j <= BoardSize)
        return value[i][j];
    else
        throw rangeError("bad value in getCell");
}

// Set the value in the cell at (i, j) to the given value
// and update conflicts

bool board::isBlank(int i, int j){
// Returns true if cell i,j is blank, and false otherwise

    if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
        throw rangeError("bad value in setCell");

    return (getCell(i,j) == Blank);
}

void board::print()
// Prints the current board.
{
    for (int i = 1; i <= BoardSize; i++)
    {
        if ((i-1) % SquareSize == 0)
        {
            cout << " -";
            for (int j = 1; j <= BoardSize; j++)
                cout << "---";
            cout << "-";
            cout << endl;
        }
        for (int j = 1; j <= BoardSize; j++)
        {
            if ((j-1) % SquareSize == 0)
                cout << "|";
            if (!isBlank(i,j))
                cout << " " << getCell(i,j) << " ";
            else
                cout << "   ";
        }
        cout << "|";
        cout << endl;
    }

    cout << " -";
    for (int j = 1; j <= BoardSize; j++)
        cout << "---";
    cout << "-";
    cout << endl;
}

//this function will set the value of each cell, updating each conflict vector
void board::setCell(int i, int j, int given){
    //set specific sell values
    value[i][j] = given;

    //update conflict vectors
    rowConflicts[i - 1][given - 1] = true; //for the rows
    colConflicts[j - 1][given - 1] = true; //for the columns
    squareConflicts[squareNumber(i, j) - 1][given - 1] = true; //for the squares
}


//This void type function prints all the conflicts that are found when iterating through the board
void board::printConflicts() {

    //for loop that iterates through each row
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for row #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":";//outputs index

            if (rowConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }

    //column conflicts are determined and printed to the screen
    cout << endl;
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for column #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":"; //outputs index
            if (colConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }

    //conflicts for each sudoku square are output
    cout << endl;
    for (int i = 0; i < BoardSize; i++) {
        cout << "Conflicts for square #" << i + 1 << " below:" << endl;

        for (int j = 0; j < BoardSize; j++) {
            cout << j + 1 << ":"; //outputs index
            if (squareConflicts[i][j]) { //if statements that check for conflict at given cell
                cout << "T  ";
            }
            else {
                cout << "F  ";
            }
        }
        cout << endl;
    }
}

//This function checks to see if the given board has been solved or not
bool board::isSolved()
{
    //For loop that iterates through all the rows and columns of the board, checking for blank squares
    for(int i = 1; i <= BoardSize; i++){
        for(int j = 1; j <= BoardSize; j++){
            if (isBlank(i,j)){
                return false; //returns false if a cell is empty
            }
        }
    }
    return true; //returns through if there are no blank cells
}

//void type function to clear a cell; takes indices for cell and a value
void board::clearCell(int i, int j, int given) {

    value[i][j] = Blank; //set initial value of a cell to -1 if empty

    //update conflicts for rows, columns, and sqaures
    rowConflicts[i - 1][given - 1] = false;
    colConflicts[j - 1][given - 1] = false;
    squareConflicts[squareNumber(i, j) - 1][given - 1] = false;
}

//This function will find the cells that are most constrained and target them so that they can be properly solved
//It essentially uses selection sort to work with the constrained cells
cell board::findConstrainCell(){

    cell constrainCell; //declares variables and sets values to begin searching for a cell that's heavily constrained
    constrainCell.i = Blank; // sets i to -1
    constrainCell.j = Blank; //sets j to -1
    constrainCell.values = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }; //sets 9 values corresponding to cells to be '-1'

    vector<int> temp; //declare a temp vector to hold values to compare

    //for loop to iterate through the entire sudoku board to find a specific cell that has the least amount of potential values that would work
    for (int i = 1; i <= BoardSize; i++) {
        for (int j = 1; j <= BoardSize; j++) {
            
            //first need to check if a given cell is blank or not
            if (isBlank(i, j)) {
                temp.clear(); //clears value if empty
                
                //for loop to check all possible values that could work in that cell
                for (int v = MinValue; v <= MaxValue; v++) { //uses variables declared in given code pdf
                    
                    //checks for any conflicts at given indices
                    if (!(rowConflicts[i-1][v-1] || colConflicts[j-1][v-1] || squareConflicts[squareNumber(i, j)-1][v-1]))
                        temp.push_back(v); //adds the possible value to temporary vector
                }
                //another if statement to check if there's another, more constrained cell
                //if so, sets the new cell to be the target cell
                if (temp.size() < constrainCell.values.size()) {
                    constrainCell.values = temp;
                    constrainCell.i = i;
                    constrainCell.j = j;
                }
            }
        }
    }
    return constrainCell; //returns value of the constrained cell
}


int recursionCount = 0; //instantiates variable

//This function is the implemetation of the part b instructions. It solves the sudoku board through recursion and backtracking
bool board::solveBoard(){
    recursionCount += 1; //increments recursion counter when running
    if (isSolved()) {return true;} //inline code to check if board is already solved

    cell keyCell = findConstrainCell(); //creates a target cell "keyCell" that is the one with the least possible value choices

    //if statement to check if cell is empty and has possible values - will backtrack
    if (keyCell.values.empty()) {return false;}

    //for loop that iterates through all the possible values for the targeted cell
    for (int validValue : keyCell.values){

        setCell(keyCell.i, keyCell.j, validValue); //gives a value to the target cell and checks for validity
        if (solveBoard()) {return true;} //uses a recursive call to check if the puzzle is solved

        else
            clearCell(keyCell.i, keyCell.j, validValue); //if condition not met, it will retry another value for that cell
    }
    return false; //will return false and backtrack if all potential values have been tried with no success
}

//takes given code and adds the extra requested functionalities such as printing the average recursion calls and total number of calls needed
int main()
{
    ifstream fin;

    string fileName = "sudoku.txt";

    cout << "Attempting to open file: " << fileName << endl;
    fin.open(fileName.c_str());
    if (!fin)
    {
        cerr << "Cannot open " << fileName << endl;
        exit(1);
    }

    try
    {

        board b1(SquareSize); //creates the sudoku board

        //declares and instantiates counter variables to be used
        int numRecursions, numGames, totalCalls = 0;

        while (fin && fin.peek() != 'Z')
        {
            b1.initialize(fin);

            cout << "Game number # " << numGames +1 << endl; //outputs the game number
            b1.print(); //prints the board as is - unsolved
            cout << (b1.isSolved() ? "Board is solved!" : "Board is not solved.") << endl; //outputs if the board is already solved or not
            cout << "Solving the board..." << endl;

            b1.solveBoard();//solves the board
            numGames++; //increments counter
            b1.print(); //reprints solved board

            cout << (b1.isSolved() ? "Board is solved!" : "Board is not solved.") << endl; //outputs if the board has now been solved
            
            //the following statements enumerates the amount of recursive calls needed to complete the board
            cout << "Recursive calls needed to solveBoard this game: " << recursionCount << endl;
            cout << "\n"; //adds new line of space
            numRecursions = numRecursions + recursionCount; //updates counter

            totalCalls += numRecursions; // calculates the total number of recursive calls
            
            //the two lines below prepare the algorithm to handle the next sudoku board
            b1.clear(); //clears board
            recursionCount = 0; //resets counter variable to zero for new board
        }


        cout << "STATISTICS: " << endl;
        //calculates and outputs the average recursive calls needed
        int avgCalls = numRecursions / numGames; //calculates the avg calls as an integer
        cout << "Average recursive calls for all games: " << avgCalls << endl;

        //prints total number of recursive calls used
        cout << "Total recursive calls: " << totalCalls << endl;
    }
    
    catch  (indexRangeError &ex)
    {
        cout << ex.what() << endl;
        exit(1);
    }
}
