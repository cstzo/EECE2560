#include <iostream>
#include <string>
#include <random>
#include <ctime>
#include <list>

using namespace std;


class Card{

public:

    //Default constructor for the card clas
    Card(){};
    
    //Constructor of Card class given two string input values
    Card(string set_value, string set_suit){
        card_val = set_value;
        suit = set_suit;
        }

    //Getter and setter for suit
    void setSuit(string suit);
    string getSuit();

    //Getter and setter for card values
    void setValue(string card_val);
    string getValue();

    //Overloaded output operator to display the card value and suit
    friend ostream& operator<<(ostream& ostr, Card card);

private:
    //Initialization of the suit and card value as string type variables - private
    string suit;
    string card_val;

};

//Setter function to set the value of a card
void Card::setValue(string card) {
    card_val = card;
}

//Setter function to set the suit of a card
void Card::setSuit(string suit_val) {
    suit = suit_val;
}

//Getter function to return the value of a card
string Card::getValue() {return card_val;}

//Getter function to return the suit of a card
string Card::getSuit() {return suit;}

//overloaded ostream output operator to display the result of user's guess in the required format (,)
ostream& operator<< (ostream& ostr, Card card){
    ostr << "Card: " << card.getValue() << " of " << card.getSuit() << endl;
    return ostr;
}

///////////////////////node/////////////////////////////

//This class was taken directly from the in-class slides
// See Page 6 of Ford-Topp_Ch9-LinkList
template <typename T>
class node{
public:
    T nodeValue;
    node<T> *next;

    node() : next(NULL) {}

    node(const T& item, node<T> *nextNode = NULL) : nodeValue(item), next(nextNode){};
private:

};


///////////////////////DECK////////////////////////
class Deck{

public:
    node<Card> *front;
    //General declaration of the Deck
    Deck();
    //Overloaded output operator for the deck
    friend ostream& operator<< (ostream& ostr, Deck& deck);
    //Function to shuffle the cards - named "shuffle_" so that we could use the "shuffle()" function from the algorithm library
    void shuffle_() const;

private:

};

Deck::Deck() {

    node<Card> *p;

    //Initiates the card numbers and suits as string types
    string suits[] = {"Hearts", "Clubs", "Diamonds", "Spades"};
    string cards[] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

    front = NULL;

    //For loop that prints each card in the deck, including the face value and suit
    for (int i=0; i<13; i++){
        for (const string& suit : suits){
            p = new node<Card>;

            p->nodeValue.setSuit(suit);
            p->nodeValue.setValue(cards[i]);

            //Condition to check if the front of the linked list is empty
            if (front == NULL){
                front = p;

            } else{
                p->next = front;
                front = p;
            }

        }
    }
}

//Overloaded output operator function
ostream& operator<< (ostream& ostr, Deck& deck){
    node<Card> *current;
    current = deck.front;

    while (current != NULL){
        cout << current->nodeValue;
        current = current->next;
    }
    return ostr;
}

//This function shuffles the cards by generating random indices within the deck which the cards will be replaced to
//It checks to see if the randomly generated indices are already taken before it moves a card so that their is no overlap
//and the number of cards remains 52 within the deck
void Deck::shuffle_() const{

    //While loop that enumerates the total nodes of the list (# of cards)
    int counter = 0;
    node<Card>* current = front;

    while (current != NULL) {
        counter++;
        current = current->next;
    }

    //Seeds the random number generator with a truly random seed
    srand(time(0));

    //For loops that runs the actual shuffling of indexes
    for (int i=0; i<counter; i++) {
        //For loops to find the cards at the given pointers
        int index1 = rand()%counter;
        int index2 = rand()%counter;

        //Swap the values of the nodes at these indices
        //Checks condition that the indices are different to not overwrite cards
        if (index1 != index2) {
            // Find the nodes at index1 and index2
            node<Card>* card1 = front;
            node<Card>* card2 = front;
            for (int i1=0; i1<index1; i1++) {
                card1 = card1->next;
            }
            for (int i2=0; i2<index2; i2++) {
                card2 = card2->next;
            }

            //Swapping data of the cards
            Card temp_card = card1->nodeValue; //generates a temporary Card class member to hold card value
            card1->nodeValue = card2->nodeValue; //swaps 1 with 2
            card2->nodeValue = temp_card; //swaps 2 with the temporary card
        }
    }

}




//////////////////////MAIN/////////////////////////

int main(){
    Deck playingDeck; //constructs a deck from class Deck

    cout << "Regular, unshuffled deck:\n" << playingDeck << endl; //outputs the unshuffled deck

    cout << "Shuffled deck: " << endl;
    playingDeck.shuffle_(); // shuffles deck
    cout << playingDeck; //outputs shuffled deck

return 0;
};