#include <iostream>
#include <string>
#include <algorithm>
#include <ctime>
#include <list>

using namespace std;

//////////////////CARD/////////////////
class Card{

public:

    //Default constructor for the card clas
    Card(){};

    //The copy constructor of Card class required by part B
    Card(const Card &);

    //Constructor of Card class given two string input values
    Card(string set_value, string set_suit){
        card_val = set_value;
        suit = set_suit;
    }


    //Getter and setter for suit
    void setSuit(string suit);
    string getSuit();

    //Getter and setter for card values
    void setValue(string card_val);
    string getValue();


    //Overloaded output operator to display the card value and suit
    friend ostream& operator<<(ostream& ostr, Card card);

    //Overloaded assignment operator for the cards
    Card& operator= (const Card&);

private:
    //Initialization of the suit and card value as string type variables - private
    string suit;
    string card_val;
};

//Setter function to set the value of a card
void Card::setValue(string card) {
    card_val = card;
}

//Setter function to set the suit of a card
void Card::setSuit(string suit_val) {
    suit = suit_val;
}

Card::Card(const Card &card){
    card_val = card.card_val;
    suit = card.suit;
}

//Getter function to return the value of a card - inline
string Card::getValue() {return card_val;}

//Getter function to return the suit of a card - inline
string Card::getSuit() {return suit;}

//overloaded ostream output operator to display the result of user's guess in the required format (,)
ostream& operator<< (ostream& ostr, Card card){
    ostr << "Card: " << card.getValue() << " of " << card.getSuit() << endl;
    return ostr;
}

//From part B - overloaded equality operator
Card &Card::operator=(const Card& card) {
    card_val = card.card_val;
    suit = card.suit;

    return *this;
}

///////////////////////node/////////////////////////////

//This class was taken directly from the in-class slides
// See Page 6 of Ford-Topp_Ch9-LinkList
template <typename T>
class node{
public:
    T nodeValue;
    node<T> *next;

    node() : next(NULL) {}

    node(const T& item, node<T> *nextNode = NULL) : nodeValue(item), next(nextNode){};

private:

};


///////////////////////DECK////////////////////////
class Deck{

public:
    node<Card> *front;
    //General declaration of the Deck
    Deck();
    //Overloaded output operator for the deck
    friend ostream& operator<< (ostream& ostr, Deck& deck);
    //Function to shuffle the cards - named "shuffle_" so that we could use the "shuffle()" function from the algorithm library
    void shuffle_() const;

    //From Part B
    ~Deck(){}; //Destructor

    //Function to deal a card from the top of the deck
    Card Deal();

    //Function to replace the currently flipped card from the deck
    void Replace(const Card&) const;

private:

};


Deck::Deck() {

    node<Card> *p;

    //Initiates the card numbers and suits as string types
    string suits[] = {"Hearts", "Clubs", "Diamonds", "Spades"};
    string cards[] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

    front = NULL;

    //For loop that prints each card in the deck, including the face value and suit
    for (int i=0; i<13; i++){
        for (const string& suit : suits){
            p = new node<Card>;

            p->nodeValue.setSuit(suit); //points to suit
            p->nodeValue.setValue(cards[i]); //points to the card face value

            //Condition to check if the front of the linked list is empty
            if (front == NULL){
                front = p;

            } else{
                p->next = front;
                front = p;
            }

        }
    }
}

//Overloaded output operator function
ostream& operator<< (ostream& ostr, Deck& deck){
    node<Card> *current;
    current = deck.front;

    while (current != NULL){
        cout << current->nodeValue;
        current = current->next;
    }
    return ostr;
}


//This function shuffles the cards by generating random indices within the deck which the cards will be replaced to
//It checks to see if the randomly generated indices are already taken before it moves a card so that their is no overlap
//and the number of cards remains 52 within the deck
void Deck::shuffle_() const{

    //While loop that enumerates the total nodes of the list (# of cards)
    int counter = 0;
    node<Card>* current = front;

    while (current != NULL) {
        counter++;
        current = current->next;
    }

    //Seeds the random number generator with a truly random seed
    srand(time(0));

    //For loops that runs the actual shuffling of indexes
    for (int i=0; i<counter; i++) {
        //Randomizes two indices every time the for loop runs and ensures they're within range
        int index1 = rand()%counter;
        int index2 = rand()%counter;

        //Swap the values of the nodes at these indices
        //Checks condition that the indices are different to not overwrite cards
        if (index1 != index2) {
            //For loops to find the cards at the given pointers
            node<Card>* card1 = front;
            node<Card>* card2 = front;
            for (int i1=0; i1<index1; i1++) {
                card1 = card1->next;
            }
            for (int i2=0; i2<index2; i2++) {
                card2 = card2->next;
            }

            //Swapping data of the cards
            Card temp_card = card1->nodeValue; //generates a temporary Card class member to hold card value
            card1->nodeValue = card2->nodeValue; //swaps 1 with 2
            card2->nodeValue = temp_card; //swaps 2 with the temporary card
        }
    }

}


//Function to deal the top card of the deck to the user and delete it after to avoid reusing it
Card Deck::Deal() {
    node<Card> *current;
    Card dealt_card;

    //Picks the card at the top of the deck to be flipped, then points to the next item in the linked list
    //since it will be the next card to be drawn
    current = front;
    dealt_card = current->nodeValue;
    front = current->next;

    delete current; //Removes the current card from the deck

    return dealt_card; //Returns value and suit of the card
}


//Function that replaces the top card when pulled
void Deck::Replace(const Card& card) const {
    node<Card> *current;
    current = front;

    //The while loop replaces the card currently flipped with the next one so that it is replaced
    //and doesn't get displayed twice
    while (current->next != NULL){
        current = current -> next;
    }

    node<Card> *p;
    p = new node<Card>;
    current->next = p;
    p->nodeValue = card;
}


//////////////////////MAIN/////////////////////////
void playFlip(){

//Initializing variables needed for the loops below to run
int user_score = 0;
int max_card_num = 24;
bool flag = false;
string input;

//Calls Deck and Card constructors
Deck game_deck;
Card user_card;


cout << "The original deck, unshuffled: \n" << game_deck;

//Shuffles the deck 3x times - could have been a for loop
game_deck.shuffle_();
game_deck.shuffle_();
game_deck.shuffle_();

cout << "\nThis is the deck after being shuffled 3x times:\n" << game_deck << endl;

//cout << "You may end the game whenever you'd like - just type 'End'" << endl;
cout << "Welcome to Flip! The game has begun.. " << endl;


while (flag != true){

    for (int current_deal_num = 0; current_deal_num < max_card_num ; current_deal_num++) {

        cout << "Draw #" << current_deal_num + 1 << endl;
        user_card = game_deck.Deal();

        cout << user_card;

        // If/else conditions to assign points to the user based on the rules of the game
        if ((user_card.getValue() == "K") || (user_card.getValue() == "Q") || (user_card.getValue() == "J")) {
            user_score += 5;
        } else if (user_card.getValue() == "A") {
            user_score += 10;
        } else if (user_card.getValue() == "8" || (user_card.getValue() == "9" || (user_card.getValue() == "10"))) {
            user_score += 0;
        } else if (user_card.getValue() == "7") {
            user_score = user_score / 2;
        } else if (user_card.getValue() == "2" || (user_card.getValue() == "3" || (user_card.getValue() == "4") ||
                                                   (user_card.getValue() == "5" || (user_card.getValue() == "6")))) {
            user_score = 0;
        }
        if (user_card.getSuit() == "Hearts") {
            user_score += 1;
        };

        cout << "Your score is: " << user_score << endl;
        cout << "\n";

        //Replaces the card just chosen to the end of the deck
        game_deck.Replace(user_card);

        cout << "Enter '1' to flip another card or type 'End' to end the game" << endl;
        cout << "Selection: ";
        cin >> input;

        //Ends game when the appropriate user input is entered
        if (input == "End") {
            flag = true;
            cout << "The game is over... Your final score is: " << user_score << endl;
            break;
        }

    }

    //Ends the game if when the maximum of 24 cards was picked
    cout << "\nThe game is over... Your final score is: " << user_score << endl;
    flag = true;
    break;

}
};



int main(){

    playFlip(); //Calls the global function to play the game

    return 0;
};
