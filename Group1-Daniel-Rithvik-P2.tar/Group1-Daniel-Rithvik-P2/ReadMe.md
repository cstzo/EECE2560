# Read me - Project 2 - Flip
## General Information
**Due date:** 2/22/24

**Class:** EECE2560 - Fundamentals of Algorithms

**Authors:** Group 1 - Daniel Costanzo and Rithvik Kaikaneni

**Note:** There are two main parts of this project present in this directory - part a (coskat-2a) and part b (coskat-2b).

## Rules of the game
Flip has the following steps:
1. The cards are shuffled three times.
2. The player draws 24 cards from the top of the deck, without looking at them, and places
   them face down on the table.
3. The player can either select a card to turn over, or end the game. If a card is turned over,
   the player:
   (a) receives 10 points for an ace,
   (b) receives 5 points for a king, queen or jack,
   (c) receives 0 points for an 8, 9 or 10,
   (d) loses half their points for a 7,
   (e) loses all their points for a 2, 3, 4, 5 or 6, and
   (f) receives 1 point extra, in addition to the above, for a heart.
4. A player’s goal is to end the game with the most points.

## Requirements
***Part a requires the following:***

Fully implement a card class that stores a single card. A card includes a value and a suit (club,
diamond, heart or spade). The class should at least include (1) a constructor, (2) setValue()
and setSuit() functions, (3) getValue() and getSuit() functions, and (4) an overloaded <<
operator to print a card’s value and suit.

Fully implement a deck class that stores the cards in a deck in order. A deck of cards should
be implemented using a linked list of nodes, each of which contains a single card. The deck
object should contain a pointer to the first card in the deck. The class should at least include (1)
a constructor that creates a deck with all the cards in order (ace-king, club-diamond-heart-spade),
(2) an overloaded << operator that prints the cards in the deck, and (3) a shuffle() function
that shuffles the cards in the deck (Use any algorithm to shuffle the cards that puts the cards in a
random order).

Include a main function that initializes a deck and prints all the cards in the deck before shuffle
and after shuffle.


***Part b requires the following:***
Complete the program that allows the user to play the card game flip:
1. Add a copy constructor and overloaded assignment operator to the card class.
2. Add a destructor to the deck class to deallocate the list of cards.
3. Add a function deal to the deck class that returns the top card in the deck. The card is also
   removed from the deck.
4. Add a function replace to the deck class that is passed a card as a parameter. The card is
   placed on the bottom of the deck.
   (*In your game, the card should be the one that you just flipped. The deck is the one that initially
   contains the cards that are not drawn by the player.)
5. Write a global function playFlip that plays the game by reading instructions from the
   keyboard (i.e., whether or not flip the next card) and printing the results (including but
   not limited to the card just flipped, the player’s current score, and whether or not the game
   is end) to the screen. You should print the top 24 cards and the remaining cards of the deck
   to the screen. Also, you should print the current hand after flipping a card to the screen.
   We’ll use the information to see if your program is working correctly.





## How to compile and run
***For part a:***

Open the `coskat2-a.cpp` file and run it through VSCode.

There is nothing that the user needs to input here. The values of the deck will be automatically displayed
to the screen for grading purposes.

***For part b:***

Open the `coskat2-b.cpp` file and run it through VSCode.

The deck of cards will be displayed. It will then be shuffled three times and will then be
outputted again to the screen.

The user will then be shown a card. They can end the game at any time by typing `End`, or can select to
flip another card by entering `1`. The game will automatically end when 24 cards are flipped or the user opts to end the game.