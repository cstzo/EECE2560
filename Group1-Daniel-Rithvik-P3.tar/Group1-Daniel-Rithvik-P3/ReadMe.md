# Read me - Project 3 - Word Search
## General Information
**Due date:** 3/18/24

**Class:** EECE2560 - Fundamentals of Algorithms

**Authors:** Group 1 - Daniel Costanzo and Rithvik Kaikaneni

**Note:** There are two main parts of this project present in this directory - part a (coskat-2a) and part b (coskat-2b).

## Scope of the project
Write a program that solves a word search puzzle. The program reads an n x n grid of letters from
a file and prints out all the words that can be found in the grid. Words can be found in the array
by starting from any letter and reading left, right, up, down, or along any of the four diagonals.
Words can also wrap around the edges of the array. Words must be at least 5 characters long.

The list of k possible words is included in the file dictionary. Several sample word search puzzles
are also provided.

The goal is to find an algorithm that solves this problem that runs as quickly as possible for large
n and k.

## Requirements
***Part a requires the following:***

1. Implement a class called dictionary that reads the words from the dictionary file and stores
   them in a vector, and which includes:
   (a) a function to read the words from the dictionary file,
   (b) a function to print the word vector,
   (c) a function that sorts the words using selectionsort,
   (d) a function to handle word lookups using binary search.


2. Implement a class called grid that reads the letters in the grid from a file and stores them
   in a matrix.


3. Implement a global function findMatches() that is passed the dictionary and the grid as
   parameters and which prints out all words that can be found in the grid.



***Part b requires the following:***
1. Implement a member function of dictionary that sorts the words using quicksort


2. Implement the template class heap<T> that stores objects in a heap of type vector<T>,
   and which includes:
   (a) functions parent(int), left(int), right(int), and getItem(int n) which re-
   turns the nth item in the heap,
   (b) for a max-heap, functions initializeMaxHeap(), maxHeapify(), and buildMaxHeap(),
   (c) function heapsort().


3. Implement a member function of dictionary that sorts the words using heapsort.
   Since the heap is only used to sort the word list, you can declare the heap within the
   dictionary::heapsort function, copy the unsorted words into the heap, sort the words,
   and then copy the words out. Then the dictionary::binarySearch function can be used
   to look up words.


4. Write the global function search(int) which reads the name of the grid file from the
   keyboard and prints out all words from the word list that can be found in the grid.
   The integer parameter is used to select the sorting algorithm used.





## How to compile and run
***For part a:***

Open the `coskat3-a.cpp` file and run it through VSCode.

The user will be prompted to enter the dictionary and grid file paths they wish to test.
Simply copy and paste the absolute paths and the script will output the list of words found.

***For part b:***

Open the `coskat3-b.cpp` file and run it through VSCode.

The user will first be prompted to enter a number that's either 1, 2, or 3 which correspond to the 
desired sorting time. Once a value is entered, the user will be prompted to enter the dictionary and grid file paths they wish to test.
Simply copy and paste the absolute paths and the script will output the list of words found.
