#include <algorithm>
#include <vector>

using namespace std;

template <typename T>
class heap{
private:

    //declares variable and vector needed for the template class
    int size;
    vector <T> heapV;

public:

    //function to get the value at index n of a heap
    int getItem(int n){
        return heapV[n];
    }

    //function to return right child node index
    int right(int n){
        int val = (2 * n) + 2;
        return val;
    }

    //function to return left child node index
    int left(int n){
        int val = (2 * n) + 1;
        return val;
    }

    //function to return the index of nth node parent from the given heap
    int parent(int n){
        int val = (n - 1) / 2;
        return val;
    }

    //initializes an unordered heap, setting its size
    void initializeMaxHeap(vector<T> v){
        heapV = v;
        size = heapV.size();
    }

    //heapifies from index n=0 until there aren't any swaps left
    void maxHeapify(int n){

        //declared variables with starting values
        int max, lhs, rhs;
        max = n;
        lhs = left(n);
        rhs = right(n);

        //if statements to set the target value for the max val of the heap
        if (lhs < size && heapV[lhs] > heapV[max]){
            max = lhs;
        }
        if (rhs < size && heapV[rhs] > heapV[max]){
            max = rhs;
        }
        //if statement to swap largest child val with the current value n if smaller than either children
        if (max != n){
            swap(heapV[max], heapV[n]);
            maxHeapify(max);
        }
    }

    //function to build a max heap from the unsorted dictionary vector passed to it
    void buildMaxHeap(){

        //takes all nodes with at least one parent
        for (int i = (parent(heapV.size()) ) - 2; i >= 0; i--){
            maxHeapify(i);
        }
    }

    //this is the actual way the heapSort function is implemented
    vector<T> heapSort(){
        buildMaxHeap(); //initialize heapification to begin

        //for loop to swap the words into their sorted order
        //it finds the largest value and puts it at the end of the heap until all sorted
        for (int i = heapV.size() - 1; i > 0; i--){
            swap(heapV[i], heapV[0]);
            size--;
            maxHeapify(0);
        }

        return heapV;
    }
};