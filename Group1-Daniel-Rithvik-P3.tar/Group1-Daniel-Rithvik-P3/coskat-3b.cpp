#include <iostream>
#include <string>
#include <random>
#include <fstream>

#include "d_matrix.h"
#include "heap.h"

using namespace std;


/////////////////////DICTIONARY CLASS//////////////////////
class Dictionary {

public:

    //function that reads the dictionary text file and adds words to a vector `allWords`
    void read(string path);

    //overloaded output operator
    friend ostream& operator<<(ostream& ostr, const Dictionary& words);

    //selection sort function prototype for dictionary
    void selectionSort();

    //binary search prototype for finding words within a given input grid
    bool binarySearch(string k);

    //vector to hold the entire dictionary
    vector<string> allWords;


    //From part B below

    //quicksort function to implement requested functionality
    void quickSort(int lhs, int rhs);

    //function that returns the size of the dictionary vector
    int getSize() const;

    //Partition function needed for the quickSort method above
    int partition(vector<string>& tempV, int start, int end);

    //prototype for heapsort function to implement requested functionality
    void heapSort();


};

void Dictionary::read(string path){

    string lineval;

    //the path is specific to my computer and needs to be modified to run elsewhere
//    path = "C:\\Users\\danie\\Downloads\\Group1-Daniel-Rithvik-P3\\dictionary";
    ifstream file(path);

    //Places every word in the dictionary into a vector
    if (file.is_open()){
        while(getline(file, lineval)){
            allWords.push_back(lineval);
        }
        //closes file once all words have been added to the new list
        file.close();
    }
}

//Overloaded output function that prints all values of the list when called
ostream& operator<<(ostream& ostr, const Dictionary& words){
    int counter = 0;
    cout << "The words below pertain to to the dictionary of all possible word choices: \n" << endl;

    //for loop to print each word of the given dictionary
    for (int i = 0; i<words.allWords.size(); i++){
        ostr << words.allWords.at(i) << endl; //outputs val
        counter += 1; //increments counter
    }

    return ostr;
}

//This function is inspired by the class module example
//Its purpose is to sort the given dictionary with selection sort method
void Dictionary::selectionSort() {
    int smallIndex, pass, j;
    long long range = allWords.size();
//pass has the range 0 ~ (range-2)
    for (pass = 0; pass < range-1; pass++)
    {
//scan the sublist starting at index pass
        smallIndex = pass;
// j traverses the sublist allWords[pass+1] to allWords[range-1]
        for (j = pass+1; j<range; j++)
//for smaller element found, assign smallIndex to that position
            if (allWords[j] < allWords[smallIndex])
                smallIndex = j;
// if smallIndex and pass are not the same location
// exchange the smallest item in the sublist with allWords[pass]
        if (smallIndex != pass)
        {
            swap(allWords[pass], allWords[smallIndex]);
        }
    }
}

//This function is a binary search that sorts through the given puzzle looking for matching words
bool Dictionary::binarySearch(string k){

    // Initialize variables
    // Determine the starting and ending index of the vector to sort
    int lhs = 0;
    int rhs = allWords.size() - 1;

    //while loop condition that checks indices against each other
    while (lhs <= rhs){

        int middle = ((lhs + rhs) / 2);

        //if target found, returns true
        if (allWords.at(middle) == k){
            return true;
        }

        //otherwise adjusts indices used to find the target word
        else if (allWords.at(middle) < k){
            lhs = middle + 1;
        }

        else {
            rhs = middle - 1;
        }
    }
    return false;
}

void Dictionary::quickSort(int lhs, int rhs) {

    //int index; //declares index variable with value 0
int index;

    if (lhs < rhs) {
//        cout << "Partitioning with left index: " << lhs << " and right index: " << rhs << endl;
        index = partition(allWords, lhs, rhs);
//        cout << "After partitioning, index is: " << index << endl;

        // Recursive call of quicksort for the left side of the list of words
        quickSort(lhs, index - 1);

        // Recursive call of quicksort for the right side of the list of words
        quickSort(index + 1, rhs);
    }
}

int Dictionary::getSize() const {return allWords.size();}

int Dictionary::partition(vector<string>& tempV, int start, int end) {
    string p = tempV[end];

    int n = start - 1;

    //for loop that iterates through the entire temporary vector of words
    for (int i = start; i < end; i++){
        //checks if the current elements is smaller than the pivot point
        //if so, swaps value at index with current val and increments n by 1
        if (tempV[i] <= p){
            n += 1;
            swap(tempV[n], tempV[i]);
        }
    }
    //places the pivot index back where it belongs by swapping with index n+1
    swap(tempV[n+1], tempV[end]);

    int val = n+1; //this index is the value to be returned by the function

    return val;
}

void Dictionary::heapSort(){

    heap<string> hp; //creates an empty heap to start
    hp.initializeMaxHeap(allWords); //copies the list of all words into the heap
    allWords = hp.heapSort(); //performs the heapsort and copies output to the list of all words
}

//////////////////GRID CLASS///////////////////////////////////
class Grid{
public:

    Grid(const string& path); //default constructor for the grid
    matrix<string> matrixGrid; //matrix for the grid

private:
};

//This constructor creates a matrix grid with the given file input from the user
Grid::Grid(const string& path){

    ifstream file(path);


    if (file.is_open()){

        //establishes needed variables and vector for the intended functionality
        int rows, columns;
        vector<string> row;
        string temp;

        //the grid dimensions are read
        file >> rows >> columns;

        //constructs the matrix using the row and column dimensions
        matrixGrid = matrix<string>(rows, columns);


        //for loop that goes through each row
        for (int i = 0; i < rows; i++) {
            // Read in all chars in row and assign it to a row of the matrix
            for (int j = 0; j < columns; j++) {
                file >> temp;
                row.push_back(temp); //appends the value to row vector
            }
            matrixGrid[i] = row;
            row.clear(); //clears row after being read
        }
    }
    file.close();

    //This was used to verify that the matrix would be properly read by displaying it back to the screen
//    for (int i = 0; i < matrixGrid.rows(); i++) {
//        for (int j = 0; j < matrixGrid.columns(); j++) {
//            cout << matrixGrid[i][j] << " ";
//        }
//        cout << endl;
//    }

}



//This function essentially finds matches between the given dictionary and selected input grid
//It uses various for loops to check the standard compass directions
//Given that the words in the given dictionary file are all 4 or more letters, this function only checks for
//words that are at least 4 letters
void findMatches(Dictionary words, const Grid& grid){

    vector<string> found;
    string tempStr; //initializes empty string
    int gridSize = grid.matrixGrid.rows(); //Sets integer size of the grid; since it is square, it has the same rows as columns


    //This for loop is the main part of this function. It iterates through the grid's rows and columns,
    //looking for words in several directions. The inner for loops are the 
    //specific directions. It can handle words that wrap around the grid by using a modulus operator
    for (int row = 0; row < grid.matrixGrid.rows(); row++) {
        for (int col = 0; col < grid.matrixGrid.cols(); col++) {

            //Checks words below
            for (int num = 0; num < grid.matrixGrid.rows(); num++) {

                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[(row + num) % (gridSize)][col];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

            //Checks words above
            for (int num = 0; num < grid.matrixGrid.rows(); num++) {

                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[(row - num + gridSize) % gridSize][col];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

            // Checks words to the right
            for (int num = 0; num < grid.matrixGrid.cols(); num++) {
                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[row][(col + num) % gridSize];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

            //Checks words to the left
            for (int num = 0; num < grid.matrixGrid.cols(); num++) {
                tempStr += grid.matrixGrid[row][(col - num + gridSize) % gridSize];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

            //Checks words diagonally down to the left
            for (int num = 0; num < grid.matrixGrid.cols(); num++) {
                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[(row + num) % (grid.matrixGrid.rows())][(col - num + grid.matrixGrid.cols()) % (grid.matrixGrid.cols())];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

            //Checks words diagonally up to the left
            for (int num = 0; num < grid.matrixGrid.rows(); num++) {
                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[(row - num + gridSize) % gridSize][(col - num + gridSize) % gridSize];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words


            //Checks words diagonally up to the right
            for (int num = 0; num < grid.matrixGrid.rows(); num++) {
                // Creates the word by concatenating the letters
                tempStr += grid.matrixGrid[(row - num + gridSize) % gridSize][(col + num) % (gridSize)];

                // If statement to validate the word is of at least 4 letters and also in the given dictionary
                if (words.binarySearch(tempStr) && tempStr.length() >= 5) {
                    found.push_back(tempStr);
                }
            }
            tempStr = "";  //resets the temp string after checking condition to allow for other words

        }
    }

    //for loop that prints all the matches found between the grid and dictionary
    cout << "List of words found: (";
    for (int i = 0; i < found.size(); i++) {
        cout << found[i] << ", ";
    }
    cout << ")" << endl;



};



void search(int choice){

    //Instantiates the dictionary, reading it from a user input file
    string userDictPath;
    cout << "Enter the path of the dictionary file you want to use: " << endl;
    cin >> userDictPath;

    Dictionary dictionary;
    dictionary.read(userDictPath);

    //Instantiates the word search grid, reading it from a user input file
    string userGridPath;
    cout << "Enter the path of the grid file you want to use: " << endl;
    cin >> userGridPath;
    Grid userGrid(userGridPath);



    //if statements to choose which sorting method to use when called
    if (choice == 1){
        cout << "Selectionsort method chosen" << endl;
        dictionary.selectionSort();
    }

    else if (choice == 2){
        cout << "Quicksort method chosen" << endl;
        dictionary.quickSort(0, dictionary.getSize());
    }

    else if (choice == 3){
        cout << "Heapsort method chosen" << endl;
        dictionary.heapSort();
    }


    //Calls the function to find the matches between input grid and dictionary word bank
    findMatches(dictionary, userGrid);
}


int main() {

    //takes user input for which sorting method to use, then calls the approproate function
    int user;

    //while loop that validates the user input
    while (true) {
        cout << "Select how you would like to sort the given dictionary. "
                "Enter 1 to use selection sort, 2 to use quicksort, and 3 to use heapsort. Enter your numeric choice: "<< endl;
        cin >> user;

        if ((user >=1 && user <=3)) {
            search(user);
            break;

        } else {
            cout << "Invalid input. Enter a whole number between 1-3. Choice: " << endl;
            cin >> user;
            search(user);
        }
        return false;
    }


    return 0;
};