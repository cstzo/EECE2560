# Read me - Project 1 - Mastermind Game
## General Information
**Due date:** 2/6/24

**Class:** EECE2560 - Fundamentals of Algorithms 

**Authors:** Group 1 - Daniel Costanzo and Rithvik Kaikaneni

**Note:** There are two main parts of this project present in this directory - part a (coskat-1a) and part b (coskat-1b).
However, there are 3 total files. The `Code.h` header file is only used by 
`coskat-1a.cpp` as the class declaration and its implementation are all within the `coskat1b-cpp` file for simplicity.

## Rules of the game
Mastermind game has the following steps:
1. The codebreaker is prompted to enter two integers: the code length n, and the range of digits
   m.
2. The codemaker selects a code: a random sequence of n digits, each of which is in the range
   [0,m-1].
3. The codebreaker is prompted to enter a guess, an n-digit sequence.
4. The codemaker responds by printing two values that indicate how close the guess is to the
   code. The first response value is the number of digits that are the right digit in the right
   location. The second response value is the number of digits that are the right digit in the
   wrong location.

5. The codebreaker is prompted to continue entering guesses. The codebreaker wins if the correct
   code is guessed in ten or fewer guesses, and otherwise the codemaker wins.

## Requirements
***Part a requires the following:***

1. Implement the class code which stores the code as a vector and contains
   (a) the code class declaration,
   (b) a constructor that is passed values n and m and initialize the code object,
   (c) a function that initializes the code randomly,
   (d) a function checkCorrect which is passed a guess as a parameter, i.e. another code
   object, and which returns the number of correct digits in the correct location,
   (e) a function checkIncorrect which is passed a guess as a parameter (i.e. another code
   object and returns the number of correct digits in the incorrect location. No digit in
   the guess or the code should be counted more than once.
2. Implement a function main() which initializes a secrete code and prints out the result of calling
   checkCorrect and checkIncorrect for three sample guess codes ((5, 0, 3, 2, 6), (2, 1, 2, 2, 2),
   (1, 3, 3, 4, 5)). Please print the secrete code as well.

***Part b requires the following:***
1. Implement the class response which stores the response to a guess (number correct and
   number incorrect), and which includes:
   (a) a constructor,
   (b) functions to set and get the individual stored values within a response,
   (c) an overloaded operator == that compares responses and returns true if they are equa
   (global),
   (d) an overloaded operator << that prints a response (global).
2. Implement the class mastermind which handles the playing of the game, and which includes:
   (a) a code object as a data member,
   (b) two constructors to initialize the game: one constructor is passed values of n and m that
   were read from the keyboard, and the other constructor is passed no parameters and
   uses default values for n = 5 and m = 10,
   (c) a function that prints the secret code,
   (d) a function humanGuess() that reads a guess from the keyboard and returns a code object
   that represents the guess,
   (e) a function getResponse() that is passed one code (a guess code), and returns a response,
   (f) a function isSolved() that is passed a response and returns true if the response indicates
   that the board has been solved.
   (g) a function playGame() that initializes a random code, prints it to the screen, and then
   iteratively gets a guess from the user and prints the response until either the codemaker
   or the codebreaker has won.
3. Implement a function main() which initializes a mastermind object and then calls playGame().
   The version of the code you submit should print the secret code to the screen to help us test
   your code.



## How to compile and run
***For part 1a:***

Open the `coskat1-a.cpp` file and run it through VSCode.
It will output values for the three given sample codes to validate the desired output.

There is nothing that the user needs to input here

***For part 2a:***

Open the `coskat1-b.cpp` file and run it through VSCode.

The user will be prompted to enter the integer `1` if they wish to play the game with their own
code length and range values, or any other integer if they wish to play with the preset values of 5 and 10.

Upon selection, the user will be prompted to enter their guess, one digit at a time. If they guess the code correctly within
`10` attempts, they will win and the game will end. Conversely, if they do not guess the secret code within `10` attempts,
the computer wins the game, and the program will terminate.