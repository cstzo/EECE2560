#include <iostream>
#include <random>
#include <ctime>
#include <set>
//#include "Code.h"
using namespace std;

/////////////////////CODE CLASS//////////////////
class Code{
public:
    Code(); //default constructor with no values passed
    Code(int n, int m); //constructor that takes two integer values as arguments

    vector<int> generateRandomValues(int n, int m); //establishes a vector that holds the digits of the secret code generated

    //instantiates the two integers variables for code length and range
    int code_length, code_range;



    //prototypes the two functions as given in the project instructions
    int checkNumCorrect(Code Guess);
    int checkNumIncorrect(Code guess);

    //Getter function for returning code
    void getCode();

    //Prototypes function to temporarily store an integer vector
    void tempSetCode(vector<int> temp);

private:
    vector<int> secret_code; //establishes a vector for the secret code as a private member of the Code class

};

//Establishes and vector of integers that will be filled by the generateRandomValues fuction
vector<int> Code::generateRandomValues(int n, int m){
    srand(time(0)); //used to actually generate an unpredictable random value

    vector<int> secret(n); //establishes a vector named "secret" of size "n"

    for (int i=0; i<n; i++){
        int randval = rand() % m; // uses modulus operator so that the random number stays within the desired range
        secret[i] = randval;
    }
    return secret;
}

Code::Code() {}

Code::Code(int n, int m){

    secret_code = generateRandomValues(n, m); //calls the function to randomly generate the code
    code_range = m; //renames user-passed range value for secret code
    code_length = n; //renames user-passed length value for secret code

}

void Code::tempSetCode(vector<int> temp){
    secret_code = temp;
}

//This function outputs the secret code to the screen digit by digit on the same line
void Code::getCode(){
    cout << "The secret code is: ";
    for (int i=0; i < code_length; i++){
        cout << secret_code[i] << " ";}
    cout << "\n";
}

//This function checks if the user's inputted code matches that of the generated secret code value by value
//If it is, it increments the correct_count counter and returns that integer value
int Code::checkNumCorrect(Code guess) {
    int correct_count = 0;
    for (int i = 0; i < guess.code_length; i++) {
        if (guess.secret_code[i] == secret_code[i]) {
            correct_count++;
        }
    }
    return correct_count;
}

//This function checks if the user's inputted code does not that of the generated secret code value by value
//If it doesn't, it adds that value to a set. The size of the set is then returned by the function which ensures numbers aren't double counted
int Code::checkNumIncorrect(Code guess) {
    int incorrect_count;
    set<int> count;

    for (int i = 0; i < code_length; i++) {
        for (int j = 0; j < code_length; j++) {
            if ((i != j) && secret_code[i] == guess.secret_code[j]) {

                count.insert(secret_code[i]);

            }
        }
    }
    incorrect_count = count.size();

    return incorrect_count;
}


/////////////////////RESPONSE CLASS//////////////////
class Response{
public:

    Response(); //default empty constructor required

    Response(int correct_number, int incorrect_number); //constructor for Response that takes two integer values

    // Required get and set functions for "Correct"
    int getCorrect() const;
    void setCorrect(int correct_number);

    // Required get and set functions for "Incorrect"
    int getIncorrect() const;
    void setIncorrect(int incorrect_number);

    //overloaded equality checker operator
    friend bool operator== (Response a, Response b);
    
    //overloaded ostream operator for outputting to console
    friend ostream& operator << (ostream& ostr, Response resp);
    
private:
    int number_incorrect, number_correct; //Establishes these integers values as number
};

Response::Response() {};

Response::Response(int correct_number, int incorrect_number){
    number_correct = correct_number;
    number_incorrect = incorrect_number;
}
//Getter and setter functions for the correct values guessed
int Response::getCorrect() const {return number_correct;}
void Response::setCorrect(int val){
    number_correct = val;
}

//Getter and setter functions for the incorrect values guessed
int Response::getIncorrect() const {return number_incorrect;}
void Response::setIncorrect(int val){
    number_incorrect = val;
}


/////////////////////MASTERMIND CLASS//////////////////
class Mastermind{

public:
    Mastermind(); //default empty constructor that will play the game with the default n=5 and m=10 values
    Mastermind(int n, int m); //constructor that takes two integers that will be user-defined


    Code humanGuess();
    Response getResponse(const Code& guess); //getter function for the user response

    void printSecretCode();
    
    bool isSolved(Response resp) const; //boolean function prototype that takes the user response and checks it to the secret code
    void playGame(); //prototype of function (void type) that holds some of the logic to play the game on the console

private:
    Code secret_code; //secret_code of Code class is set as a private data member
    
};

//defaults the secret code to use an n value of 5 and m value of 10 if no integers are passed by the user
Mastermind::Mastermind() : secret_code(5,10) {}

//basic constructor that takes in an input n for code length and m for range of digits
Mastermind::Mastermind(int n, int m) : secret_code(n, m) {}

//This function calls reads a guess from the keyboard
Code Mastermind::humanGuess() {

    Code temp_guess_val(secret_code.code_length, secret_code.code_range);
    vector<int> temp(secret_code.code_length); //vector of code length size declared

    cout << "Enter " << secret_code.code_length << " digits one at a time" << endl;
    int user_num = 0;
    bool valid_input_flag = false; //boolean flag for validating the user's input

    //Loop to get the user input for each digit one at a time until 'code_length' (n) digits are entered
        for (int i = 0; i < secret_code.code_length; i++) {
            while (valid_input_flag != true) {
                cout << "Enter digit (#" << (i + 1) << "): ";
                cin >> user_num;

                //checks if user inputted value is above the entered range
                if (user_num < 0) {

                    valid_input_flag = false;
                    cout << "The number you entered is below the entered range.. Go again." << endl;

                    // checks if user inputted value is above the entered range
                } else if (user_num > secret_code.code_range - 1) {

                    valid_input_flag = false;
                    cout << "The number you entered surpasses the range.. Go again." << endl;

                    //if not above or below, valid_input_flag set to be true
                } else {valid_input_flag = true;}
            }

            valid_input_flag = false; //ends loop once n number of digits are inputted by the user
            temp[i] = user_num; //sets the user input to an array value

        }
        temp_guess_val.tempSetCode(temp); //assigns user input for it to be passed

        return temp_guess_val;
    }

//overloaded comparison operator as given in Quiz 2
bool operator== (Response lhs, Response rhs){
    if(lhs.getCorrect() == rhs.getCorrect()){
        if(lhs.getIncorrect() == rhs.getIncorrect()){return true;}
    }
    return false;
}

//overloaded ostream output operator to display the result of user's guess in the required format (,)
ostream& operator<< (ostream& ostr, Response resp){
    ostr << "Result of your guess: (" << resp.getCorrect() << "," << resp.getIncorrect() << ")" << endl;
    return ostr;
}

Response Mastermind::getResponse(const Code& guess){
    Response temp_resp(0,0); // initializes user response to have values 0 and 0 for correct and incorrect values

    temp_resp.setIncorrect(secret_code.checkNumIncorrect(guess));
    temp_resp.setCorrect(secret_code.checkNumCorrect(guess));

    return temp_resp;
}


//Boolean type function that checks if the number of correct digits matches the total length of the secret code (n value)
bool Mastermind::isSolved(Response resp) const{
    if(resp.getCorrect() == secret_code.code_length){return true;}
    else {return false;}
}

void Mastermind::printSecretCode(){secret_code.getCode();}

void Mastermind::playGame(){

    //initializes Code class data members that essentially take n and m values as arguments
    Code user_guess(secret_code.code_length, secret_code.code_range);
    Code original_secret_code(secret_code.code_length, secret_code.code_range);
    Mastermind user_code;

    Response res(0,0);
    original_secret_code.getCode(); //calls getter function to get the secret code and output it

    //variable declaration for the loops below
    bool solved_flag = false;
    int attempt = 1;
    int max_attempt = 10;

    //while loop that runs until the solved flag is "True" or attempts run out
    while(solved_flag != true && attempt <= max_attempt + 1){

        user_guess = humanGuess(); //calls the humanGuess function and sets that value to be a variable 'user_guess'

        res = getResponse(user_guess); //pulls the user's guess using the getResponse getter function and outputs the result of their guess

        //calls isSolved function and awatds the user the win if the number of correct digits matches the length of the secret code
        if(isSolved(res) == true){
            cout << "You've correctly guessed the code, congrats! You win!" << endl;
            solved_flag = true;
            break; //ends loop and game if condition met

        }else if(attempt == max_attempt-1){     //checks if the user has exceeded the number of maximum guesses (10) and terminates the game accordingly
            cout <<"Too many guesses, you lose!" << endl;
            break; //ends loop and game if condition met
        }
        else{
            cout << res; //if other conditions not met, outputs the result of the user's guess
        }

        attempt++; //increments attempt counter
        cout << "Guess #" << attempt << ": " << endl; //outputs the current guess # for user reference
    }
}

/////////////////////MAIN//////////////////
int main(){
    //variable declaration
    int user_choice;
    int n, m;

    cout << "Welcome to Mastermind! \n Enter 1 to select your own code length and range of values. Any other integer input will play the preset version.\n Selection: ";
    cin >> user_choice;

    if (user_choice == 1) {
        cout << "You chose your own game.. Let's begin with taking your inputs" << endl;

        cout << "Enter the number of digits you'd like in the code: ";
        cin >> n;

        cout << "Enter the range digits you'd like in the code: ";
        cin >> m;

        cout << "\n";

        Mastermind game(n, m);
        game.playGame();
    }

    //plays the game using the default n = 5 and m = 10 values
    else{
        cout << "You chose to play the preset game.. Let's begin." << endl;
        Mastermind preset_game;
        preset_game.playGame();
    }

    return 0;
}