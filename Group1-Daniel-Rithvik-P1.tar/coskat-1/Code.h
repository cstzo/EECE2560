#include <iostream>
#include <random>
#include <string>

using namespace std;

#ifndef COSKAT_1_CODE_H
#define COSKAT_1_CODE_H

class Code{

public:
    Code();
    Code(int n, int m);

    vector<int> generateRandomValues(int n, int m);

    //instantiates the two integers variables for code length and range
    int code_length, code_range;

    //prototypes the two functions as given in the project instructions
    int checkCorrect(Code Guess);
//    int checkCorrect(vector<int> g);
    int checkIncorrect(Code guess);

    //Getter function for returning code
    void getCode();

    //
    void tempSetCode(vector<int> temp);



private:
    vector<int> secret_code;

};

#endif //COSKAT_1_CODE_H
