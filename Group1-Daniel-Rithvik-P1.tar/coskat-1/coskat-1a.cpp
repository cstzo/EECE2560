#include <iostream>
#include <random>
#include <string>
#include <ctime>
#include <set>

#include "Code.h"

using namespace std;

//This function generates a random code based on two inputs: 1) desired length 2) desired range
//It uses the seed 0 for time to ensure a truly randomized number
vector <int> Code::generateRandomValues(int n, int m){
    srand(time(0));

    vector<int> secret(n); //establishes a vector named "secret" of size "n"

    for (int i=0; i < n; i++){
        int randval = rand() % m; // uses modulus operator so that the random number stays within the desired range
        secret[i] = randval;
}
return secret;
}


Code::Code(int n, int m){
    secret_code = generateRandomValues(n, m); //calls the function to randomly generate the code
    code_range = m; //renames user-passed range value for secret code
    code_length = n; //renames user-passed length value for secret code

    }

void Code::tempSetCode(vector<int> temp){
    secret_code = temp;
}

//This function outputs the secret code to the screen
void Code::getCode(){
    cout << "The secret code is: ";
    for (int i=0; i < code_length; i++){
        cout << secret_code[i] << " ";
    }

    cout << "\n";
}

    //This function checks if the user's inputted code matches that of the generated secret code value by value
    //If it is, it increments the correct_count counter and returns that integer value
    int Code::checkCorrect(Code guess) {
        int correct_count = 0;
        for (int i = 0; i < guess.code_length; i++) {
            if (guess.secret_code[i] == secret_code[i]) {
                correct_count++;
            }
        }
        return correct_count;
    }

    //This function checks if the user's inputted code does not that of the generated secret code value by value
    //If it doesn't, it adds that value to a set. The size of the set is then returned by the function which ensures numbers aren't double counted
    int Code::checkIncorrect(Code guess) {
        int incorrect_count;
        set<int> count;

        for (int i = 0; i < code_length; i++) {
            for (int j = 0; j < code_length; j++) {
                if ((i != j) && secret_code[i] == guess.secret_code[j]) {

                    count.insert(secret_code[i]);

                }
            }
        }
        incorrect_count = count.size();

        return incorrect_count;
    }



//This int main function tests the three given guesses from the project assignment
int main() {
    
    // generates a secret code of 5 digits, from values 0-6 as required by part a - 2
    Code test(5, 7);
    
    // Output the secret code once to the screen 
    test.getCode(); 

    // creates vectors with the three sample guess codes given
    vector<int> given_code1 = {5, 0, 3, 2, 6};
    vector<int> given_code2 = {2, 1, 2, 2, 2};
    vector<int> given_code3 = {1, 3, 3, 4, 5};

    // create 3 Code class objects
    Code guessCode1(given_code1.size(), test.code_range), guessCode2(given_code2.size(), test.code_range), guessCode3(given_code3.size(), test.code_range);

    // assigns the three guess codes, so they can be properly passed
    guessCode1.tempSetCode(given_code1);
    guessCode2.tempSetCode(given_code2);
    guessCode3.tempSetCode(given_code3);

    // Output results of numbers correct and incorrect - formatting irrelevant
    cout << "Guess 1: (" << test.checkCorrect(guessCode1) << "," << test.checkIncorrect(guessCode1) << ")" <<endl;
    cout << "Guess 2: (" << test.checkCorrect(guessCode2) << "," << test.checkIncorrect(guessCode2) << ")" <<endl;
    cout << "Guess 3: (" << test.checkCorrect(guessCode3) << "," << test.checkIncorrect(guessCode3) << ")" <<endl;

    return 0;
}
